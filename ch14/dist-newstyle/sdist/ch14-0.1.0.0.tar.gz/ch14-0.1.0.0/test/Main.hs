module Main (main) where

import MyLib 
import Test.Hspec
import Test.QuickCheck

main :: IO ()
main = hspec $ do
  describe "Addition" $ do
    it "15 divided by 3 is 5" $ do
        dividedBy 15 3 `shouldBe` (5, 0)
    it "22 divided by 5 is 4 rem 2" $ do
        dividedBy 22 5 `shouldBe` (4,2)
    it "3 recursive mult 3 is 9" $ do
        integral 3 3 `shouldBe` 9
    it "4 recursive mult 10 is 40" $ do
        integral 4 10 `shouldBe` 40