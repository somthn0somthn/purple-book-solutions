module MyLib where

sayHello :: IO ()
sayHello = putStrLn "Jello!"

someFunction :: Int -> Int
someFunction x = x + 1

dividedBy :: Integral a => a -> a -> (a, a)
dividedBy num denom = go num denom 0
  where go n d count
         | n < d = (count, n)
         | otherwise =
            go (n - d) d (count + 1)

integral :: (Integral a) => a -> a -> a
integral num  mult = go num mult 0
   where go n  m tot 
          | m == 0 = tot
          | otherwise =
               go n (m - 1) (tot + n)